package com.example.project

class sppreguler (
    val id : String,
    val edt_nm : String,
    val kelas : String,
    val nisn : String,
    val editTextDate : String,
    val bulan : String,
    val jmlh2 : String
    ){
        constructor(): this("","","","", "", "", ""){

        }
    }